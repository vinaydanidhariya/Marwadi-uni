# declare global variable
message = 'Hello Vinay'

def Global_v():
    print('Local', message)

Global_v()
print('Global', message)




    


#nonlocal variables

def outer():
    message="Local"

    def inner():
        nonlocal message
        print("inner:",message)

    inner()
    print("outer:",message)

outer()



        
